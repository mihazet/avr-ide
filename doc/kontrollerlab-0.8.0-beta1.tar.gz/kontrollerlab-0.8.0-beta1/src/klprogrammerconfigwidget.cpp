/***************************************************************************
 *   Copyright (C) 2006 by Martin Strasser                                 *
 *   strasser  a t  cadmaniac  d o t  org                                  *
 *   Special thanks to Mario Boikov                                        *
 *   squeeze  a t  cadmaniac  d o t  org                                   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#include "klprogrammerconfigwidget.h"
#include "klprogrammerinterface.h"
#include "klprogrammeruisp.h"
#include "klprogrammeravrdude.h"
#include "kontrollerlab.h"

#include <qradiobutton.h>
#include <qlineedit.h>
#include <qcheckbox.h>
#include <kurlrequester.h>
#include <knuminput.h>
#include <kconfig.h>
#include <kapp.h>
#include <qregexp.h>


KLProgrammerConfigWidget::KLProgrammerConfigWidget(KontrollerLab *parent, const char *name)
    :KLProgrammerConfigWidgetBase(parent, name)
{
    m_parent = parent;
    setModal( true );

    KLProgrammerUISP* uisp = (KLProgrammerUISP*) m_parent->getProgrammer( UISP );
    KLProgrammerAVRDUDE* avrdude = (KLProgrammerAVRDUDE*) m_parent->getProgrammer( AVRDUDE );

    QStringList list = uisp->programmerTypesKeyList();
    for ( unsigned int i = 0; i < list.count(); i++ )
        cbUISPProgrammer->insertItem( uisp->getProgrammerTypeGUIStringFor( list[i] ) );

    list = avrdude->programmerTypesKeyList();
    for ( unsigned int i = 0; i < list.count(); i++ )
        cbAVRDUDEProgrammerType->insertItem( avrdude->getProgrammerTypeGUIStringFor( list[i] ) );

    list = uisp->parallelPortsKeyList();
    for ( unsigned int i = 0; i < list.count(); i++ )
    {
        cbUISPParallelPort->insertItem( uisp->getParallelPortGUIStringFor( list[i] ) );
    }
    list = avrdude->parallelPortsKeyList();
    for ( unsigned int i = 0; i < list.count(); i++ )
    {
        cbAVRDUDEConnectionPort->insertItem( avrdude->getParallelPortGUIStringFor( list[i] ) );
    }

    list = uisp->serialPortsKeyList();
    for ( unsigned int i = 0; i < list.count(); i++ )
    {
        cbUISPSerialPort->insertItem( uisp->getSerialPortGUIStringFor( list[i] ) );
    }
    list = avrdude->serialPortsKeyList();
    for ( unsigned int i = 0; i < list.count(); i++ )
    {
        cbAVRDUDEConnectionPort->insertItem( avrdude->getSerialPortGUIStringFor( list[i] ) );
    }

    m_configuration = m_parent->programmerConfig();
    updateGUIFromConfig();
}

void KLProgrammerConfigWidget::slotCancel()
{
    hide();
}


void KLProgrammerConfigWidget::slotOK()
{

    updateConfigFromGUI();
    m_parent->setProgrammerConfig( m_configuration );

    hide();
}

void KLProgrammerConfigWidget::slotSerialPortChanged( const QString& val )
{
    KLProgrammerUISP* uisp = (KLProgrammerUISP*) m_parent->getProgrammer( UISP );

    QString buffer = uisp->getSerialPortFor( val );
    if ( (buffer == USER_KEY) || (buffer.isEmpty() || buffer.isNull() ) )
        cbUISPSerialPort->setEditable( true );
    else
        cbUISPSerialPort->setEditable( false );
}


void KLProgrammerConfigWidget::slotParallelPortChanged( const QString& val )
{
    KLProgrammerUISP* uisp = (KLProgrammerUISP*) m_parent->getProgrammer( UISP );

    QString buffer = uisp->getParallelPortFor( val );
    if ( (buffer == USER_KEY) || (buffer.isEmpty() || buffer.isNull() ) )
        cbUISPParallelPort->setEditable( true );
    else
        cbUISPParallelPort->setEditable( false );
}

void KLProgrammerConfigWidget::updateGUIFromConfig( )
{
    if ( config( PROGRAMMER_NAME, UISP ) == UISP )
    {
        rbUISP->setChecked( true );
        leUISPCommand->setText( config(PROGRAMMER_COMMAND, "uisp") );
        leUISPCommand->setFocus( );
    }
    else
    {
        rbAVRDUDE->setChecked( true );
        leAVRDUDECommand->setText( config(PROGRAMMER_COMMAND, "avrdude") );
        leAVRDUDECommand->setFocus( );
    }

    KLProgrammerUISP* uisp = (KLProgrammerUISP*) m_parent->getProgrammer( UISP );
    KLProgrammerAVRDUDE* avrdude = (KLProgrammerAVRDUDE*) m_parent->getProgrammer( AVRDUDE );
    bool ok;
    
    // Get the unique shell args for the user visible strings:
    cbUISPProgrammer->setCurrentText( uisp->getProgrammerTypeGUIStringFor( config( UISP_PROGRAMMER_TYPE ) ) );
    cbUISPParallelPort->setCurrentText( uisp->getParallelPortGUIStringFor( config( UISP_PARALLEL_PORT ) ) );
    cbUISPSerialPort->setCurrentText( uisp->getSerialPortGUIStringFor( config( UISP_SERIAL_PORT ) ) );
    
    cbSpecifyPart->setChecked( config( UISP_SPECIFY_PART ) == TRUE_STRING );
    cbNoDataPolling->setChecked( config( UISP_PARALLEL_NO_DATA_POLLING ) == TRUE_STRING );
    cbDisableRetries->setChecked( config( UISP_PARALLEL_DISABLE_RETRIES ) == TRUE_STRING );
    cbAT89SProgramming->setChecked( config( UISP_PARALLEL_AT89S ) == TRUE_STRING );
    sbUISPVoltage->setValue( config( UISP_PARALLEL_VOLTAGE ).toDouble( &ok ) );
    sbUISPHighLowTime->setValue( config( UISP_PARALLEL_SCK_HIGH_LOW_TIME ).toDouble( &ok ) );
    sbUISPFlashMaxWriteDelay->setValue( config( UISP_PARALLEL_FLASH_MAX_WRITE_DELAY ).toDouble( &ok ) );
    sbUISPEEPROMMaxWriteDelay->setValue( config( UISP_PARALLEL_EEPROM_MAX_WRITE_DELAY ).toDouble( &ok ) );
    sbUISPResetHighTime->setValue( config( UISP_PARALLEL_RESET_HIGH_TIME ).toDouble( &ok ) );
    cbUISPSerialSpeed->setCurrentText( config( UISP_SERIAL_SPEED, "9600" ) );
    cbUISPUseHighVoltage->setChecked( config( UISP_STK500_USE_HIGH_VOLTAGE ) == TRUE_STRING );
    sbUISPARef->setValue( config( UISP_STK500_AREF_VOLTAGE ).toDouble( &ok ) );
    sbUISPVtarget->setValue( config( UISP_STK500_VTARGET_VOLTAGE ).toDouble( &ok ) );
    sbOscillatorFrequency->setValue( config( UISP_STK500_OSCILLATOR_FREQUENCY ).toDouble( &ok ) );
    
// AVRDUDE STUFF:
    
    cbAVRDUDEOverrideBaudRate->setChecked( config( AVRDUDE_OVERRIDE_BAUD_RATE, "_unset_" ) != "_unset_" );
    cbAVRDUDESpecifyBitClock->setChecked( config( AVRDUDE_SPECIFY_BIT_CLOCK, "_unset_" ) != "_unset_" );
    cbAVRDUDESpecifyProgrammerType->setChecked( config( AVRDUDE_PROGRAMMER_TYPE, "_unset_" ) != "_unset_" );
    cbAVRDUDESpecifyConnectionPort->setChecked( config( AVRDUDE_CONNECTION_PORT, "_unset_" ) != "_unset_" );
    cbAVRDUDESpecifyExternalConfigFile->setChecked( config( AVRDUDE_EXTERNAL_CONFIG_FILE, "_unset_" ) != "_unset_" );
    cbAVRDUDEDisableAutoErase->setChecked( config( AVRDUDE_DISABLE_AUTO_ERASE, "_unset_" ) == TRUE_STRING );
    cbAVRDUDEDoNotWriteAnything->setChecked( config( AVRDUDE_TEST_MODE, "_unset_" ) == TRUE_STRING );
    cbAVRDUDEOverrideInvalidSignatureCheck->setChecked( config( AVRDUDE_OVERRIDE_INVALID_SIGNATURE, "_unset_" ) == TRUE_STRING );
    cbAVRDUDECountErases->setChecked( config( AVRDUDE_COUNT_ERASE, "_unset_" ) == TRUE_STRING );
    
    if ( cbAVRDUDEOverrideBaudRate->isChecked() )
        cbBAUDRate->setCurrentText( config( AVRDUDE_OVERRIDE_BAUD_RATE, "9600" ) );
    if ( cbAVRDUDESpecifyBitClock->isChecked() )
        cbBitClockPeriodUS->setValue( config( AVRDUDE_SPECIFY_BIT_CLOCK, "5.0" ).toDouble( &ok ) );
    if ( cbAVRDUDESpecifyProgrammerType->isChecked() )
        cbAVRDUDEProgrammerType->setCurrentText(
            avrdude->getProgrammerTypeGUIStringFor( config( AVRDUDE_PROGRAMMER_TYPE, "" ) ) );
    if ( cbAVRDUDESpecifyConnectionPort->isChecked() )
        cbAVRDUDEConnectionPort->setCurrentText(
            avrdude->getPortGUIStringFor( config( AVRDUDE_CONNECTION_PORT, "" ) ) );
    if ( cbAVRDUDESpecifyExternalConfigFile->isChecked() )
        kurlExternalConfigFile->setURL( config( AVRDUDE_EXTERNAL_CONFIG_FILE, "" ) );
}


QString KLProgrammerConfigWidget::config( const QString & key, const QString & defVal )
{
    if ( m_configuration.find( key ) != m_configuration.end() )
        return m_configuration[ key ];
    else
    {
        kapp->config()->setGroup("KontrollerLab");
        QString val = kapp->config()->readEntry( key, "" );
        if ( (!val.isEmpty()) && (!val.isNull()) )
            return val;
        else
            return defVal;
    }
}


void KLProgrammerConfigWidget::slotSetDefault( )
{
    updateConfigFromGUI();
    
    QMap<QString, QString>::Iterator it;
    kapp->config()->setGroup("KontrollerLab");
    
    kapp->config()->deleteEntry(AVRDUDE_OVERRIDE_BAUD_RATE);
    kapp->config()->deleteEntry(AVRDUDE_SPECIFY_BIT_CLOCK);
    kapp->config()->deleteEntry(AVRDUDE_PROGRAMMER_TYPE);
    kapp->config()->deleteEntry(AVRDUDE_CONNECTION_PORT);
    kapp->config()->deleteEntry(AVRDUDE_EXTERNAL_CONFIG_FILE);
    
    for ( it = m_configuration.begin(); it != m_configuration.end(); ++it )
    {
        kapp->config()->writeEntry( it.key(), it.data() );
    }
    kapp->config()->sync();
}


void KLProgrammerConfigWidget::updateConfigFromGUI( )
{
    m_configuration.clear();

    if ( rbUISP->isChecked() )
    {
        m_configuration[PROGRAMMER_NAME] = UISP;
        m_configuration[PROGRAMMER_COMMAND] = leUISPCommand->text();
    }
    if ( rbAVRDUDE->isChecked() )
    {
        m_configuration[PROGRAMMER_NAME] = AVRDUDE;
        m_configuration[PROGRAMMER_COMMAND] = leAVRDUDECommand->text();
    }

    KLProgrammerUISP* uisp = (KLProgrammerUISP*) m_parent->getProgrammer( UISP );
    KLProgrammerAVRDUDE* avrdude = (KLProgrammerAVRDUDE*) m_parent->getProgrammer( AVRDUDE );
    

    // Get the unique shell args for the user visible strings:
    m_configuration[UISP_PROGRAMMER_TYPE] = uisp->getProgrammerTypeFor( cbUISPProgrammer->currentText() );
    m_configuration[UISP_PARALLEL_PORT] = uisp->getParallelPortFor( cbUISPParallelPort->currentText() );
    m_configuration[UISP_SERIAL_PORT] = uisp->getSerialPortFor( cbUISPSerialPort->currentText() );

    m_configuration[UISP_SPECIFY_PART] = cbSpecifyPart->isChecked() ? TRUE_STRING : FALSE_STRING;
    m_configuration[UISP_PARALLEL_NO_DATA_POLLING] = cbNoDataPolling->isChecked() ? TRUE_STRING : FALSE_STRING;
    m_configuration[UISP_PARALLEL_DISABLE_RETRIES] = cbDisableRetries->isChecked() ? TRUE_STRING : FALSE_STRING;
    m_configuration[UISP_PARALLEL_AT89S] = cbAT89SProgramming->isChecked() ? TRUE_STRING : FALSE_STRING;
    m_configuration[UISP_PARALLEL_VOLTAGE] = QString( "%1" ).arg( sbUISPVoltage->value() );
    m_configuration[UISP_PARALLEL_SCK_HIGH_LOW_TIME] = QString( "%1" ).arg( sbUISPHighLowTime->value() );
    m_configuration[UISP_PARALLEL_FLASH_MAX_WRITE_DELAY] = QString( "%1" ).arg( sbUISPFlashMaxWriteDelay->value() );
    m_configuration[UISP_PARALLEL_EEPROM_MAX_WRITE_DELAY] = QString( "%1" ).arg( sbUISPEEPROMMaxWriteDelay->value() );
    m_configuration[UISP_PARALLEL_RESET_HIGH_TIME] = QString( "%1" ).arg( sbUISPResetHighTime->value() );
    m_configuration[UISP_SERIAL_SPEED] = cbUISPSerialSpeed->currentText();
    m_configuration[UISP_STK500_USE_HIGH_VOLTAGE] = cbUISPUseHighVoltage->isChecked() ? TRUE_STRING : FALSE_STRING;
    m_configuration[UISP_STK500_AREF_VOLTAGE] = QString( "%1" ).arg( sbUISPARef->value() );
    m_configuration[UISP_STK500_VTARGET_VOLTAGE] = QString( "%1" ).arg( sbUISPVtarget->value() );
    m_configuration[UISP_STK500_OSCILLATOR_FREQUENCY] = QString( "%1" ).arg( sbOscillatorFrequency->value() );
    
    // AVRDUDE STUFF:
    
    m_configuration[ AVRDUDE_DISABLE_AUTO_ERASE ] = cbAVRDUDEDisableAutoErase->isChecked()? TRUE_STRING:FALSE_STRING;
    m_configuration[ AVRDUDE_TEST_MODE ] = cbAVRDUDEDoNotWriteAnything->isChecked()? TRUE_STRING:FALSE_STRING;
    m_configuration[ AVRDUDE_OVERRIDE_INVALID_SIGNATURE ] = cbAVRDUDEOverrideInvalidSignatureCheck->isChecked()? TRUE_STRING:FALSE_STRING;
    m_configuration[ AVRDUDE_COUNT_ERASE ] = cbAVRDUDECountErases->isChecked()? TRUE_STRING:FALSE_STRING;
    
    if ( cbAVRDUDEOverrideBaudRate->isChecked() )
        m_configuration[ AVRDUDE_OVERRIDE_BAUD_RATE ] = cbBAUDRate->currentText();
    if ( cbAVRDUDESpecifyBitClock->isChecked() )
        m_configuration[ AVRDUDE_SPECIFY_BIT_CLOCK ] = QString("%1").arg(cbBitClockPeriodUS->value());
    if ( cbAVRDUDESpecifyProgrammerType->isChecked() )
        m_configuration[ AVRDUDE_PROGRAMMER_TYPE ] =
                avrdude->getProgrammerTypeFor( cbAVRDUDEProgrammerType->currentText() );
    if ( cbAVRDUDESpecifyConnectionPort->isChecked() )
        m_configuration[ AVRDUDE_CONNECTION_PORT ] =
                avrdude->getPortFor( cbAVRDUDEConnectionPort->currentText() );
    if ( cbAVRDUDESpecifyExternalConfigFile->isChecked() )
        m_configuration[ AVRDUDE_EXTERNAL_CONFIG_FILE ] = kurlExternalConfigFile->url();

}


void KLProgrammerConfigWidget::showEvent( QShowEvent * )
{
    m_configuration = m_parent->programmerConfig();
    updateGUIFromConfig();
}

void KLProgrammerConfigWidget::slotWriteSTK500()
{
    KLProgrammerUISP* uisp = (KLProgrammerUISP*) m_parent->getProgrammer( UISP );
    QMap< QString, QString > oldConfig = uisp->configuration();

    bool uispSelected = rbUISP->isChecked();
    rbUISP->setChecked( true );
    updateConfigFromGUI();
    uisp->configuration() = m_configuration;
    uisp->writeSTK500( sbUISPARef->value(),
                       sbUISPVtarget->value(),
                       sbOscillatorFrequency->value() );
    rbUISP->setChecked( uispSelected );
    rbAVRDUDE->setChecked( !uispSelected );
    uisp->configuration() = oldConfig;
}


void KLProgrammerConfigWidget::slotReadSTK500()
{
    KLProgrammerUISP* uisp = (KLProgrammerUISP*) m_parent->getProgrammer( UISP );
    QMap< QString, QString > oldConfig = uisp->configuration();

    bool uispSelected = rbUISP->isChecked();
    rbUISP->setChecked( true );
    updateConfigFromGUI();
    uisp->configuration() = m_configuration;
    uisp->readSTK500( );
    rbUISP->setChecked( uispSelected );
    rbAVRDUDE->setChecked( !uispSelected );
    uisp->configuration() = oldConfig;
}


void KLProgrammerConfigWidget::slotSetEraseCounter()
{
    KLProgrammerAVRDUDE* avrdude = (KLProgrammerAVRDUDE*) m_parent->getProgrammer( AVRDUDE );

    QMap< QString, QString > oldConfig = avrdude->configuration();

    bool avrdudeSelected = rbAVRDUDE->isChecked();
    rbAVRDUDE->setChecked( true );
    updateConfigFromGUI();
    avrdude->configuration() = m_configuration;
    avrdude->setEraseCounter( sbEraseCount->value() );
    rbUISP->setChecked( !avrdudeSelected );
    rbAVRDUDE->setChecked( avrdudeSelected );
    avrdude->configuration() = oldConfig;
}


void KLProgrammerConfigWidget::backannotateSTK500( const QString & stdout )
{
    QStringList list = QStringList::split( "\n", stdout );

    bool ok;

    QRegExp reARef( "AREF\\s*=\\s*([0-9]*\\.[0-9]*)\\s*V" );
    QRegExp reVSup( "VTARGET\\s*=\\s*([0-9]*\\.[0-9]*)\\s*V" );
    QRegExp reClk( "FREQUENCY\\s*=\\s*([0-9]*\\.[0-9]*)\\s*HZ" );

    for ( QStringList::iterator it = list.begin();
          it != list.end(); ++it )
    {
        QString line = (*it).upper();
        if ( reARef.search( line ) != -1 )
            sbUISPARef->setValue( reARef.cap( 1 ).toDouble( &ok ) );
        if ( reVSup.search( line ) != -1 )
            sbUISPVtarget->setValue( reVSup.cap( 1 ).toDouble( &ok ) );
        if ( reClk.search( line ) != -1 )
            sbOscillatorFrequency->setValue( reClk.cap( 1 ).toDouble( &ok ) );
    }
}


#include "klprogrammerconfigwidget.moc"
