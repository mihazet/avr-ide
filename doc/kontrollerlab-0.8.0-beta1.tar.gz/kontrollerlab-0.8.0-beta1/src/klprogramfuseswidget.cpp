/***************************************************************************
 *   Copyright (C) 2006 by Martin Strasser                                 *
 *   strasser  a t  cadmaniac  d o t  org                                  *
 *   Special thanks to Mario Boikov                                        *
 *   squeeze  a t  cadmaniac  d o t  org                                   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#include "klprogramfuseswidget.h"
#include "klcpufuses.h"
#include "klproject.h"
#include "klprogrammerinterface.h"
#include <qcheckbox.h>
#include <kmessagebox.h>
#include <klocale.h>
#include <qcombobox.h>
#include "kldocumentview.h"


KLProgramFusesWidget::KLProgramFusesWidget(QWidget *parent, KLProject* project, const char *name)
    :KLProgramFusesWidgetBase(parent, name), m_project( project )
{
    m_fuses = m_project->getFusesFor( m_project->cpu() );
    
    m_highByte = m_lowByte = m_extByte = m_lockByte = 0xFF;
    updateGUIFromData();
    
    cbCPU->insertStringList( m_project->cpus() );
}

void KLProgramFusesWidget::slotClose()
{
    close();
}


void KLProgramFusesWidget::slotWrite()
{
    updateDataFromGUI();

    int retVal = KMessageBox::questionYesNo( this,
                                             i18n("Do You really want do write the fuses? "
                                                  "This can damage the CPU irreparably."),
                                             i18n("Fuse bits"),
                                             KStdGuiItem::yes(), KStdGuiItem::no(),
                                             "kontrollerlab_write_fuses" );

    if ( retVal == KMessageBox::Yes )
    {
        QMap< QString, QString > fuses;
        fuses[ FUSE_L ] = QString("0x%1").arg( m_lowByte, 0, 16 );
        fuses[ FUSE_H ] = QString("0x%1").arg( m_highByte, 0, 16 );
        fuses[ FUSE_E ] = QString("0x%1").arg( m_extByte, 0, 16 );
        fuses[ FUSE_LOCK ] = QString("0x%1").arg( m_lockByte, 0, 16 );
        m_project->programFuses( fuses, cbCPU->currentText() );
    }

}


void KLProgramFusesWidget::slotRead()
{
    m_project->readFuses( cbCPU->currentText() );
}


void KLProgramFusesWidget::updateGUIFromData()
{
    cbExt0->setEnabled( m_fuses.extCanBeChanged()[0] );
    cbExt1->setEnabled( m_fuses.extCanBeChanged()[1] );
    cbExt2->setEnabled( m_fuses.extCanBeChanged()[2] );
    cbExt3->setEnabled( m_fuses.extCanBeChanged()[3] );
    cbExt4->setEnabled( m_fuses.extCanBeChanged()[4] );
    cbExt5->setEnabled( m_fuses.extCanBeChanged()[5] );
    cbExt6->setEnabled( m_fuses.extCanBeChanged()[6] );
    cbExt7->setEnabled( m_fuses.extCanBeChanged()[7] );
    cbExt0->setText( m_fuses.extNames()[0] );
    cbExt1->setText( m_fuses.extNames()[1] );
    cbExt2->setText( m_fuses.extNames()[2] );
    cbExt3->setText( m_fuses.extNames()[3] );
    cbExt4->setText( m_fuses.extNames()[4] );
    cbExt5->setText( m_fuses.extNames()[5] );
    cbExt6->setText( m_fuses.extNames()[6] );
    cbExt7->setText( m_fuses.extNames()[7] );

    cbLow0->setEnabled( m_fuses.lowCanBeChanged()[0] );
    cbLow1->setEnabled( m_fuses.lowCanBeChanged()[1] );
    cbLow2->setEnabled( m_fuses.lowCanBeChanged()[2] );
    cbLow3->setEnabled( m_fuses.lowCanBeChanged()[3] );
    cbLow4->setEnabled( m_fuses.lowCanBeChanged()[4] );
    cbLow5->setEnabled( m_fuses.lowCanBeChanged()[5] );
    cbLow6->setEnabled( m_fuses.lowCanBeChanged()[6] );
    cbLow7->setEnabled( m_fuses.lowCanBeChanged()[7] );
    cbLow0->setText( m_fuses.lowNames()[0] );
    cbLow1->setText( m_fuses.lowNames()[1] );
    cbLow2->setText( m_fuses.lowNames()[2] );
    cbLow3->setText( m_fuses.lowNames()[3] );
    cbLow4->setText( m_fuses.lowNames()[4] );
    cbLow5->setText( m_fuses.lowNames()[5] );
    cbLow6->setText( m_fuses.lowNames()[6] );
    cbLow7->setText( m_fuses.lowNames()[7] );

    cbHigh0->setEnabled( m_fuses.highCanBeChanged()[0] );
    cbHigh1->setEnabled( m_fuses.highCanBeChanged()[1] );
    cbHigh2->setEnabled( m_fuses.highCanBeChanged()[2] );
    cbHigh3->setEnabled( m_fuses.highCanBeChanged()[3] );
    cbHigh4->setEnabled( m_fuses.highCanBeChanged()[4] );
    cbHigh5->setEnabled( m_fuses.highCanBeChanged()[5] );
    cbHigh6->setEnabled( m_fuses.highCanBeChanged()[6] );
    cbHigh7->setEnabled( m_fuses.highCanBeChanged()[7] );
    cbHigh0->setText( m_fuses.highNames()[0] );
    cbHigh1->setText( m_fuses.highNames()[1] );
    cbHigh2->setText( m_fuses.highNames()[2] );
    cbHigh3->setText( m_fuses.highNames()[3] );
    cbHigh4->setText( m_fuses.highNames()[4] );
    cbHigh5->setText( m_fuses.highNames()[5] );
    cbHigh6->setText( m_fuses.highNames()[6] );
    cbHigh7->setText( m_fuses.highNames()[7] );
    
    cbChecked->setPaletteForegroundColor( foregroundColor() );
    cbUnchecked->setPaletteForegroundColor( foregroundColor() );
    
    int mask = 0;
    for ( int i = 0; i < 8; i++ )
    {
        mask = 1 << i;
        if ( 0 == i )
            cbHigh0->setChecked( !(mask & m_highByte) );
        else if ( 1 == i )
            cbHigh1->setChecked( !(mask & m_highByte) );
        else if ( 2 == i )
            cbHigh2->setChecked( !(mask & m_highByte) );
        else if ( 3 == i )
            cbHigh3->setChecked( !(mask & m_highByte) );
        else if ( 4 == i )
            cbHigh4->setChecked( !(mask & m_highByte) );
        else if ( 5 == i )
            cbHigh5->setChecked( !(mask & m_highByte) );
        else if ( 6 == i )
            cbHigh6->setChecked( !(mask & m_highByte) );
        else if ( 7 == i )
            cbHigh7->setChecked( !(mask & m_highByte) );
    
        if ( 0 == i )
            cbLow0->setChecked( !(mask & m_lowByte) );
        else if ( 1 == i )
            cbLow1->setChecked( !(mask & m_lowByte) );
        else if ( 2 == i )
            cbLow2->setChecked( !(mask & m_lowByte) );
        else if ( 3 == i )
            cbLow3->setChecked( !(mask & m_lowByte) );
        else if ( 4 == i )
            cbLow4->setChecked( !(mask & m_lowByte) );
        else if ( 5 == i )
            cbLow5->setChecked( !(mask & m_lowByte) );
        else if ( 6 == i )
            cbLow6->setChecked( !(mask & m_lowByte) );
        else if ( 7 == i )
            cbLow7->setChecked( !(mask & m_lowByte) );
    
        if ( 0 == i )
            cbExt0->setChecked( !(mask & m_extByte) );
        else if ( 1 == i )
            cbExt1->setChecked( !(mask & m_extByte) );
        else if ( 2 == i )
            cbExt2->setChecked( !(mask & m_extByte) );
        else if ( 3 == i )
            cbExt3->setChecked( !(mask & m_extByte) );
        else if ( 4 == i )
            cbExt4->setChecked( !(mask & m_extByte) );
        else if ( 5 == i )
            cbExt5->setChecked( !(mask & m_extByte) );
        else if ( 6 == i )
            cbExt6->setChecked( !(mask & m_extByte) );
        else if ( 7 == i )
            cbExt7->setChecked( !(mask & m_extByte) );
    
        if ( 0 == i )
            cbLock0->setChecked( !(mask & m_lockByte) );
        else if ( 1 == i )
            cbLock1->setChecked( !(mask & m_lockByte) );
        else if ( 2 == i )
            cbLock2->setChecked( !(mask & m_lockByte) );
        else if ( 3 == i )
            cbLock3->setChecked( !(mask & m_lockByte) );
        else if ( 4 == i )
            cbLock4->setChecked( !(mask & m_lockByte) );
        else if ( 5 == i )
            cbLock5->setChecked( !(mask & m_lockByte) );
        else if ( 6 == i )
            cbLock6->setChecked( !(mask & m_lockByte) );
        else if ( 7 == i )
            cbLock7->setChecked( !(mask & m_lockByte) );
    }
}


void KLProgramFusesWidget::updateDataFromGUI()
{
    int mask = 0;
    m_highByte = m_lockByte = m_lowByte = m_extByte = 0;
    for ( int i = 0; i < 8; i++ )
    {
        mask = 1 << i;
        if ( ( 0 == i ) && cbHigh0->isChecked() ) m_highByte |= mask;
        else if ( ( 1 == i ) && cbHigh1->isChecked() ) m_highByte |= mask;
        else if ( ( 2 == i ) && cbHigh2->isChecked() ) m_highByte |= mask;
        else if ( ( 3 == i ) && cbHigh3->isChecked() ) m_highByte |= mask;
        else if ( ( 4 == i ) && cbHigh4->isChecked() ) m_highByte |= mask;
        else if ( ( 5 == i ) && cbHigh5->isChecked() ) m_highByte |= mask;
        else if ( ( 6 == i ) && cbHigh6->isChecked() ) m_highByte |= mask;
        else if ( ( 7 == i ) && cbHigh7->isChecked() ) m_highByte |= mask;
    
        if ( ( 0 == i ) && cbLow0->isChecked() ) m_lowByte |= mask;
        else if ( ( 1 == i ) && cbLow1->isChecked() ) m_lowByte |= mask;
        else if ( ( 2 == i ) && cbLow2->isChecked() ) m_lowByte |= mask;
        else if ( ( 3 == i ) && cbLow3->isChecked() ) m_lowByte |= mask;
        else if ( ( 4 == i ) && cbLow4->isChecked() ) m_lowByte |= mask;
        else if ( ( 5 == i ) && cbLow5->isChecked() ) m_lowByte |= mask;
        else if ( ( 6 == i ) && cbLow6->isChecked() ) m_lowByte |= mask;
        else if ( ( 7 == i ) && cbLow7->isChecked() ) m_lowByte |= mask;
    
        if ( ( 0 == i ) && cbExt0->isChecked() ) m_extByte |= mask;
        else if ( ( 1 == i ) && cbExt1->isChecked() ) m_extByte |= mask;
        else if ( ( 2 == i ) && cbExt2->isChecked() ) m_extByte |= mask;
        else if ( ( 3 == i ) && cbExt3->isChecked() ) m_extByte |= mask;
        else if ( ( 4 == i ) && cbExt4->isChecked() ) m_extByte |= mask;
        else if ( ( 5 == i ) && cbExt5->isChecked() ) m_extByte |= mask;
        else if ( ( 6 == i ) && cbExt6->isChecked() ) m_extByte |= mask;
        else if ( ( 7 == i ) && cbExt7->isChecked() ) m_extByte |= mask;
    
        if ( ( 0 == i ) && cbLock0->isChecked() ) m_lockByte |= mask;
        else if ( ( 1 == i ) && cbLock1->isChecked() ) m_lockByte |= mask;
        else if ( ( 2 == i ) && cbLock2->isChecked() ) m_lockByte |= mask;
        else if ( ( 3 == i ) && cbLock3->isChecked() ) m_lockByte |= mask;
        else if ( ( 4 == i ) && cbLock4->isChecked() ) m_lockByte |= mask;
        else if ( ( 5 == i ) && cbLock5->isChecked() ) m_lockByte |= mask;
        else if ( ( 6 == i ) && cbLock6->isChecked() ) m_lockByte |= mask;
        else if ( ( 7 == i ) && cbLock7->isChecked() ) m_lockByte |= mask;
    }
    m_highByte = ~m_highByte;
    m_lockByte = ~m_lockByte;
    m_lowByte = ~m_lowByte;
    m_extByte = ~m_extByte;
}


void KLProgramFusesWidget::showEvent( QShowEvent* )
{
    m_fuses = m_project->getFusesFor( m_project->cpu() );
    updateGUIFromData();
    cbCPU->setCurrentText( m_project->cpu() );
}


void KLProgramFusesWidget::setFuseBits( unsigned char lowByte,
                                        unsigned char highByte,
                                        unsigned char extByte,
                                        unsigned char lockByte )
{
    m_lockByte = lockByte;
    m_lowByte = lowByte;
    m_highByte = highByte;
    m_extByte = extByte;
    updateGUIFromData();
}

void KLProgramFusesWidget::setFuseBits( const QString & lowByte,
                                        const QString & highByte,
                                        const QString & extByte,
                                        const QString & lockByte )
{
    unsigned char lowB, highB, extB, lockB;
    bool ok1, ok2, ok3, ok4;
    lowB = lowByte.toUShort( &ok1, 16 );
    highB = highByte.toUShort( &ok2, 16 );
    lockB = lockByte.toUShort( &ok3, 16 );
    extB = extByte.toUShort( &ok4, 16 );
    
    if ( ok1 && ok2 && ok3 && ok4 )
    {
        m_highByte = highB;
        m_lowByte = lowB;
        m_extByte = extB;
        m_lockByte = lockB;
        updateGUIFromData();
    }
    else
    {
        qWarning( "There was an error while converting the " \
                "fuse bit strings to hex values in %s:%d.", __FILE__, __LINE__ );
    }
}

void KLProgramFusesWidget::slotCPUChanged( const QString& name )
{
    m_fuses = m_project->getFusesFor( name );
    updateGUIFromData();
}



#include "klprogramfuseswidget.moc"
