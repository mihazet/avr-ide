/***************************************************************************
 *   Copyright (C) 2006 by Martin Strasser                                 *
 *   strasser  a t  cadmaniac  d o t  org                                  *
 *   Special thanks to Mario Boikov                                        *
 *   squeeze  a t  cadmaniac  d o t  org                                   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#include "klprojectconfigwidget.h"
#include "klprojectmanagerwidget.h"
#include <qlayout.h>
#include "klproject.h"
#include <qcombobox.h>
#include <qlabel.h>
#include <klocale.h>
#include <knuminput.h>
#include <qlineedit.h>
#include <qcheckbox.h>
#include <qradiobutton.h>
#include <qlistview.h>
#include <kapplication.h>
#include <kconfig.h>


KLProjectConfigWidget::KLProjectConfigWidget(KLProject* project, QWidget *parent, const char *name)
    :KLProjectConfigWidgetBase(parent, name), m_validator(QRegExp("0x[0-9a-fA-F]{1,4}"), this, "reValidator")
{
    m_project = project;
    m_projectManagerInConfigWidget =
            new KLProjectManagerWidget( project, tab, "managerInConfig" );
    m_projectManagerInConfigWidget->setConfigButtonVisible( false );
    layProjectManager->addWidget( m_projectManagerInConfigWidget );
    cbCPU->clear();
    // Add all the CPUs:
    cbCPU->insertStringList( project->cpus() );
    // Update the project files list:
    project->update();
    // Fill the linker flags list:
    m_possibleLinkerFlags["-Wl,-lm"] = i18n("Link with math library");
    m_possibleLinkerFlags["-Wl,-lprintf"] = i18n("Link with printf library");
    m_possibleLinkerFlags["-Wl,-lprintf_min"] = i18n("Link with printf_min library");
    m_possibleLinkerFlags["-Wl,-u,vfprintf -Wl,-lprintf_flt"] = i18n("Link with floating point printf library");
    QStringList keys = m_possibleLinkerFlags.keys();
    keys.sort();

    for ( QStringList::iterator it = keys.begin(); it != keys.end(); ++it )
    {
        QCheckListItem* cur = new QCheckListItem( lvLinkerFlags, m_possibleLinkerFlags[*it], QCheckListItem::CheckBox );
        cur->setText( 1, *it );
        m_linkerFlagsCBs.append( cur );
    }
    updateGUIFromSettings();
    updateCPUInfo( cbCPU->currentText() );

    kisbStartOfText->setValidator(&m_validator);
    kisbStartOfData->setValidator(&m_validator);
    kisbStartOfBSS->setValidator(&m_validator);
    kisbStartOfHeap->setValidator(&m_validator);
    kisbEndOfHeap->setValidator(&m_validator);
}

void KLProjectConfigWidget::slotCancel()
{
    hide();
}


void KLProjectConfigWidget::slotSetDefault()
{
    QMap<QString, QString>::Iterator it;
    kapp->config()->setGroup("KontrollerLab");
    updateSettingsFromGUI();
    // m_settings = settings();

    kapp->config()->deleteEntry( PRJ_CPU );
    kapp->config()->deleteEntry( PRJ_CLOCKSPEED );
    kapp->config()->deleteEntry( PRJ_EXTERNAL_RAM );
    kapp->config()->deleteEntry( PRJ_HEX_FILE );
    kapp->config()->deleteEntry( PRJ_MAP_FILE );
    kapp->config()->deleteEntry( PRJ_COMPILER_COMMAND );
    kapp->config()->deleteEntry( PRJ_COMPILER_CALL_PROLOGUES );
    kapp->config()->deleteEntry( PRJ_COMPILER_STRICT_PROTOTYPES );
    kapp->config()->deleteEntry( PRJ_COMPILER_WALL );
    kapp->config()->deleteEntry( PRJ_COMPILER_GDEBUG );
    kapp->config()->deleteEntry( PRJ_COMPILER_OPT_LEVEL );
    kapp->config()->deleteEntry( PRJ_LINKER_COMMAND );
    kapp->config()->deleteEntry( PRJ_OBJCOPY_COMMAND );
    kapp->config()->deleteEntry( PRJ_LINKER_START_TEXT );
    kapp->config()->deleteEntry( PRJ_LINKER_START_DATA );
    kapp->config()->deleteEntry( PRJ_LINKER_START_BSS );
    kapp->config()->deleteEntry( PRJ_LINKER_START_HEAP );
    kapp->config()->deleteEntry( PRJ_LINKER_END_HEAP );
    kapp->config()->deleteEntry( PRJ_LINKER_FLAGS );
    kapp->config()->deleteEntry( PRJ_ASSEMBLER_COMMAND );
    kapp->config()->deleteEntry( PRJ_COMPILER_F_CPU );
    for ( it = m_settings.begin(); it != m_settings.end(); ++it )
    {
        // qDebug("%s = %s", it.key().ascii(), it.data().ascii() );
        kapp->config()->writeEntry( it.key(), it.data() );
    }
    kapp->config()->sync();
}


void KLProjectConfigWidget::slotOK()
{
    updateSettingsFromGUI();
    m_project->setSettings( m_settings );
    hide();
}


void KLProjectConfigWidget::slotCPUChanged( const QString& name )
{
    updateCPUInfo( name );
}


void KLProjectConfigWidget::updateCPUInfo( const QString& name )
{
    KLCPUFeatures feat = m_project->cpuFeaturesFor( name );
    lblInternalRAMBytes->setText( i18n("%1 Bytes").arg(feat.internalRAMSize()) );
    lblClockMHz->setText( i18n("%1 MHz").arg(feat.maxClockSpeedHz()/1e6) );
    lblEEPROMBytes->setText( i18n("%1 Bytes").arg(feat.EEPROMSize()) );
    lblFLASHEEPROMBytes->setText( i18n("%1 Bytes").arg(feat.flashEEPROMSize()) );
}


void KLProjectConfigWidget::updateSettingsFromGUI( )
{
    QString buffer;
    QMap< QString, QString > retVal;
    retVal[ PRJ_CPU ] = cbCPU->currentText();
    retVal[ PRJ_CLOCKSPEED ] = buffer.setNum( kdsClock->value() );
    if ( cbExternalRAM->isChecked() )
        retVal[ PRJ_EXTERNAL_RAM ] = buffer.setNum( sbSize->value() );
    retVal[ PRJ_HEX_FILE ] = leHEXFile->text();
    retVal[ PRJ_MAP_FILE ] = leMAPFile->text();
    retVal[ PRJ_COMPILER_COMMAND ] = leCompilerCommand->text();
    retVal[ PRJ_COMPILER_CALL_PROLOGUES ] = cbCallPrologues->isChecked() ? TRUE_STRING : FALSE_STRING;
    retVal[ PRJ_COMPILER_STRICT_PROTOTYPES ] = cbStrictPrototypes->isChecked() ? TRUE_STRING : FALSE_STRING;
    retVal[ PRJ_COMPILER_WALL ] = cbAll->isChecked() ? TRUE_STRING : FALSE_STRING;
    retVal[ PRJ_COMPILER_GDEBUG ] = cbGDebug->isChecked() ? TRUE_STRING : FALSE_STRING;
    retVal[ PRJ_COMPILER_F_CPU ] = cbFCPU->isChecked() ? TRUE_STRING : FALSE_STRING;
    retVal[ PRJ_COMPILER_OPT_LEVEL ] = cbOptimizationLevel->currentText().left(1).lower();
    retVal[ PRJ_LINKER_COMMAND ] = leLinkerCommand->text();
    retVal[ PRJ_OBJCOPY_COMMAND ] = leObjectCopyCommand->text();
    if ( cbStartOfText->isChecked() )
        retVal[ PRJ_LINKER_START_TEXT ] = QString("%1").arg(kisbStartOfText->value(), 0, 16);
    if ( cbStartOfData->isChecked() )
        retVal[ PRJ_LINKER_START_DATA ] = QString("%1").arg(kisbStartOfData->value(), 0, 16);
    if ( cbStartOfBSS->isChecked() )
        retVal[ PRJ_LINKER_START_BSS ] = QString("%1").arg(kisbStartOfBSS->value(), 0, 16);
    if ( cbStartOfHeap->isChecked() )
        retVal[ PRJ_LINKER_START_HEAP ] = QString("%1").arg(kisbStartOfHeap->value(), 0, 16);
    if ( cbEndOfHeap->isChecked() )
        retVal[ PRJ_LINKER_END_HEAP ] = QString("%1").arg(kisbEndOfHeap->value(), 0, 16);
    retVal[ PRJ_ASSEMBLER_COMMAND ] = leAssemblerCommand->text();
    
    QCheckListItem* it;
    QString allFlags;
    for ( it = m_linkerFlagsCBs.first(); it; it = m_linkerFlagsCBs.next() )
    {
        if ( it->state() == QCheckListItem::On )
        {
            allFlags += it->text( 1 ) + "#";
        }
    }
    if ( allFlags.length() > 0 )
        allFlags = allFlags.left( allFlags.length()-1 );
    // qDebug("allFlags is %s", allFlags.ascii());
    retVal[ PRJ_LINKER_FLAGS ] = allFlags;

    retVal[ PRJ_BUILD_SYSTEM ] = PRJ_BUILT_IN_BUILD_SYSTEM;
    if ( rbExecuteMake->isChecked() )
        retVal[ PRJ_BUILD_SYSTEM ] = PRJ_EXECUTE_MAKE;

    retVal[ PRJ_MAKE_COMMAND ] = leMake->text();
    retVal[ PRJ_MAKE_DEFAULT_TARGET ] = leDefaultTarget->text();
    retVal[ PRJ_MAKE_CLEAN_TARGET ] = leCleanTarget->text();

    m_settings = retVal;
}


void KLProjectConfigWidget::updateGUIFromSettings()
{
    bool ok;

    for (int i=0; i<cbCPU->count(); i++)
        if ( cbCPU->text( i ) == conf( PRJ_CPU, "AT90S8515" ) )
            cbCPU->setCurrentItem( i );
    kdsClock->setValue( (int) conf( PRJ_CLOCKSPEED, "4000000" ).toDouble( &ok ) );
    
    cbExternalRAM->setChecked( conf( PRJ_EXTERNAL_RAM, "unspec" ) != "unspec" );
    if ( cbExternalRAM->isChecked() )
        sbSize->setValue( conf( PRJ_EXTERNAL_RAM, "65356" ).toInt(&ok) );
    
    leHEXFile->setText( conf( PRJ_HEX_FILE, "project.hex" ) );
    leMAPFile->setText( conf( PRJ_MAP_FILE, "project.map" ) );
    leCompilerCommand->setText( conf( PRJ_COMPILER_COMMAND, "avr-gcc" ) );
    cbCallPrologues->setChecked( conf( PRJ_COMPILER_CALL_PROLOGUES, FALSE_STRING ) == TRUE_STRING );
    cbStrictPrototypes->setChecked( conf( PRJ_COMPILER_STRICT_PROTOTYPES, FALSE_STRING ) == TRUE_STRING );
    cbFCPU->setChecked( conf( PRJ_COMPILER_F_CPU, FALSE_STRING ) == TRUE_STRING );
    cbAll->setChecked( conf( PRJ_COMPILER_WALL, FALSE_STRING ) == TRUE_STRING );
    cbGDebug->setChecked( conf( PRJ_COMPILER_GDEBUG, FALSE_STRING ) == TRUE_STRING );
    QString optVal = conf( PRJ_COMPILER_OPT_LEVEL, "0" ).lower();
    for ( int i=0; i < cbOptimizationLevel->count(); i++ )
        if ( cbOptimizationLevel->text( i ).left(1) == optVal )
            cbOptimizationLevel->setCurrentItem( i );

    leLinkerCommand->setText( conf( PRJ_LINKER_COMMAND, "avr-gcc" ) );
    leObjectCopyCommand->setText( conf( PRJ_OBJCOPY_COMMAND, "avr-objcopy" ) );

    cbStartOfText->setChecked( conf( PRJ_LINKER_START_TEXT, "unspec" ) != "unspec" );
    if ( cbStartOfText->isChecked() )
        kisbStartOfText->setValue( conf( PRJ_LINKER_START_TEXT, "0" ).toInt(&ok, 16) );

    cbStartOfData->setChecked( conf( PRJ_LINKER_START_DATA, "unspec" ) != "unspec" );
    if ( cbStartOfData->isChecked() )
        kisbStartOfData->setValue( conf( PRJ_LINKER_START_DATA, "0" ).toInt(&ok, 16) );

    cbStartOfBSS->setChecked( conf( PRJ_LINKER_START_BSS, "unspec" ) != "unspec" );
    if ( cbStartOfBSS->isChecked() )
        kisbStartOfBSS->setValue( conf( PRJ_LINKER_START_BSS, "0" ).toInt(&ok, 16) );

    cbStartOfHeap->setChecked( conf( PRJ_LINKER_START_HEAP, "unspec" ) != "unspec" );
    if ( cbStartOfHeap->isChecked() )
        kisbStartOfHeap->setValue( conf( PRJ_LINKER_START_HEAP, "0" ).toInt(&ok, 16) );

    cbEndOfHeap->setChecked( conf( PRJ_LINKER_END_HEAP, "unspec" ) != "unspec" );
    if ( cbEndOfHeap->isChecked() )
        kisbEndOfHeap->setValue( conf( PRJ_LINKER_END_HEAP, "0" ).toInt( &ok, 16 ) );
    
    leAssemblerCommand->setText( conf( PRJ_ASSEMBLER_COMMAND, "avr-gcc" ) );
    
    QStringList allFlags = QStringList::split( "#", conf( PRJ_LINKER_FLAGS, "" ) );
    // qDebug("allFlags is %s", allFlags.join("!!").ascii());
    QStringList::iterator it;
    QCheckListItem* it2;
    for ( it = allFlags.begin(); it != allFlags.end(); ++it )
    {
        // qDebug("searching: %s", (*it).ascii() );
        for ( it2 = m_linkerFlagsCBs.first(); it2; it2 = m_linkerFlagsCBs.next() )
        {
            if ( it2->text( 1 ).stripWhiteSpace() == (*it).stripWhiteSpace() )
            {
                // qDebug( "Found" );
                it2->setState( QCheckListItem::On );
            }
        }
    }
    
    if ( conf( PRJ_BUILD_SYSTEM, PRJ_BUILT_IN_BUILD_SYSTEM ) == PRJ_BUILT_IN_BUILD_SYSTEM )
        rbBuiltIn->setChecked( true );
    else
        rbExecuteMake->setChecked( true );
    
    leMake->setText( conf( PRJ_MAKE_COMMAND, "make" ) );
    leDefaultTarget->setText( conf( PRJ_MAKE_DEFAULT_TARGET, "all" ) );
    leCleanTarget->setText( conf( PRJ_MAKE_CLEAN_TARGET, "clean" ) );
}


QString KLProjectConfigWidget::conf( const QString & confKey, const QString & defval ) const
{
    if ( m_settings.contains( confKey ) )
    {
        // qDebug("found for %s : %s", confKey.ascii(), m_settings[ confKey ].ascii());
        return m_settings[ confKey ];
    }
    else
    {
        kapp->config()->setGroup("KontrollerLab");
        QString val = kapp->config()->readEntry( confKey, "" );
        // qDebug("%s empty=%d null=%d", val.ascii(), val.isEmpty(), val.isNull() );
        if ( (!val.isEmpty()) && (!val.isNull()) )
        {
            // qDebug("%s = %s", confKey.ascii(), val.ascii());
            return val;
        }
        else
        {
            // qDebug("returning defval %s for %s", defval.ascii(), confKey.ascii() );
            return defval;
        }
    }
}

void KLProjectConfigWidget::showEvent( QShowEvent * )
{
    m_settings = m_project->settings();
    updateGUIFromSettings();
}

void KLProjectConfigWidget::slotBuildSystemChanged()
{
    if ( rbExecuteMake->isChecked() )
        tlWarning->hide();
    else
        tlWarning->show();
}



#include "klprojectconfigwidget.moc"
