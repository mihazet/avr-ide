/***************************************************************************
 *   Copyright (C) 2006 by Martin Strasser                                 *
 *   strasser  a t  cadmaniac  d o t  org                                  *
 *   Special thanks to Mario Boikov                                        *
 *   squeeze  a t  cadmaniac  d o t  org                                   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#ifndef KLSEVENSEGMENTWIDGET_H
#define KLSEVENSEGMENTWIDGET_H

#include "klsevensegmentwidgetbase.h"
#include <qptrlist.h>
#include <qvaluelist.h>
#include <qradiobutton.h>
#include <qlistview.h>

class KLDocument;
        

class KLSevenSegmentWidget: public KLSevenSegmentWidgetBase {
Q_OBJECT
public:
    KLSevenSegmentWidget(QWidget *parent, const char *name, KLDocument* doc);
    ~KLSevenSegmentWidget();
public slots:
    virtual void slotCurrentItemChanged( QListViewItem* cur );
    virtual void slotBitSegmentAssocChanged();
    virtual void slotDP();
    virtual void slotG();
    virtual void slotF();
    virtual void slotE();
    virtual void slotD();
    virtual void slotC();
    virtual void slotB();
    virtual void slotA();
    virtual void slotCancel();
    virtual void slotOK();
    virtual void slotDown();
    virtual void slotUp();
    virtual void slotRemove();
    virtual void slotAdd();
protected:
    bool underReedit() const { return (m_startLine>=0)&&(m_stopLine>=0); }
    QString formStr( int nr ) const;
    QPixmap generatePixmapFor( int segs );
    QValueList< int > generateBitmasks();
    int getSegmentsForListItem( QListViewItem* item );
    int curSegments() { return getSegmentsForListItem( lvSegments->currentItem() ); }
    void setListItemForSegments( QListViewItem* item, int segs );
    void changeCurrentListItem();
    QValueList < int > readBitSegmentAssignmentFromRadios();
    void setRadiosFromBitSegmentAssignment( QValueList < int > assign );
    QValueList < QPtrList<QRadioButton> > m_radios;
    QValueList < int > m_segmentIsBit;
    bool m_prohibitRecursion, m_dontReactOnToolButtons;
    KLDocument* m_document;
    // If we reedit something:
    int m_startLine, m_stopLine;
    QString m_whiteSpace;
};

#endif
