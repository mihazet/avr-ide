/***************************************************************************
 *   Copyright (C) 2006 by Martin Strasser                                 *
 *   strasser  a t  cadmaniac  d o t  org                                  *
 *   Special thanks to Mario Boikov                                        *
 *   squeeze  a t  cadmaniac  d o t  org                                   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#ifndef KLDOTMATRIXCHARACTERWIZARD_H
#define KLDOTMATRIXCHARACTERWIZARD_H

#include "kldotmatrixcharacterwizardbase.h"
#include "kleditdotswidget.h"
#include <qlistview.h>
#include <qpixmap.h>

class KLProject;
class KLDocument;

class KLDotMatrixCharacterListViewItem : public QListViewItem
{
public:
    KLDotMatrixCharacterListViewItem( int number, QValueList<int> masks,
                                      QListView *parent, const char *name );
    void update( QValueList<int> masks );
    QValueList< int > masks() const { return m_masks; }

    void setNumber(const int& theValue) { m_number = theValue; updateNumberString(); }
    int number() const { return m_number; }
    KLDotMatrixCharacterListViewItem* nextSibling();
protected:
    QPixmap generatePixmapFor( QValueList< int > masks );
    QValueList<int> m_masks;
    void updateNumberString();
    int m_number;
};


class KLDotMatrixCharacterWizard: public KLDotMatrixCharacterWizardBase {
Q_OBJECT
public:
    KLDotMatrixCharacterWizard(QWidget *parent, const char *name, KLProject* project, KLDocument* doc);
public slots:
    virtual void slotCharacterChanged();
    virtual void slotOK();
    virtual void slotSizeChanged();
    virtual void slotSelectedCharacterChanged( QListViewItem* );
    virtual void slotDown();
    virtual void slotUp();
    virtual void slotRemove();
    virtual void slotAdd();
    virtual void slotCancel();
protected:
    bool underReedit() const { return (m_startLine>=0)&&(m_stopLine>=0); }
    int m_startLine, m_stopLine;
    QString m_whiteSpace;

    void reNumber();
    KLProject* m_project;
    KLDocument* m_document;
    QGridLayout* m_frmGridLayout;
    KLEditDotsWidget* m_editDots;
};

#endif
