//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ScintillaDemo.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_SCINTILLA_FINDDLGORD        101
#define IDD_SCINTILLA_REPLACEDLGORD     102
#define IDR_MAINFRAME                   128
#define IDR_SCINTITYPE                  129
#define IDS_SCINTILLA_DEFAULT_PRINT_HEADER 130
#define IDS_SCINTILLA_DEFAULT_PRINT_FOOTER 131
#define IDS_TOOLBAR                     132
#define IDP_ALLOW_MODIFY_READONLY_FILE  133
#define IDC_REGULAR_EXPRESSION          1042
#define ID_LANGUAGE_VBSCRIPT            32771
#define ID_OPTIONS_VIEW_LINENUMBERS     32771
#define ID_OPTIONS_SELECTION_MARGIN     32779
#define ID_OPTIONS_FOLD_MARGIN          32780
#define ID_OPTIONS_ADDMARKER            32781
#define ID_OPTIONS_DELETEMARKER         32782
#define ID_OPTIONS_FIND_NEXTMARKER      32783
#define ID_OPTIONS_FIND_PREVMARKER      32784
#define ID_INDICATOR_LINE               61446
#define IDS_LINE_INDICATOR              61447
#define ID_INDICATOR_STYLE              61448
#define IDS_STYLE_INDICATOR             61449
#define ID_INDICATOR_FOLD               61450
#define IDS_FOLD_INDICATOR              61451

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
